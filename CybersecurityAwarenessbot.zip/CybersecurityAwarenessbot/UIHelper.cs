﻿using System;
using System.Threading;

namespace CyberSecurityAwarenessbot
{
    public static class UIHelper
    {
        public static void DisplayLogo()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;

            Console.WriteLine("===========================================");
            Console.WriteLine("       CYBERSECURITY AWARENESS BOT         ");
            Console.WriteLine("===========================================");
            Console.WriteLine(@" 
██████╗██╗██████╗ ██╗  ██╗███████╗██████╗ ████████╗ ██████╗  ██████╗ ██╗     
██╔════╝██║██╔══██╗██║  ██║██╔════╝██╔══██╗╚══██╔══╝██╔═══██╗██╔═══██╗██║     
██║     ██║██████╔╝███████║█████╗  ██████╔╝   ██║   ██║   ██║██║   ██║██║     
██║     ██║██╔═══╝ ██╔══██║██╔══╝  ██╔══██╗   ██║   ██║   ██║██║   ██║██║     
╚██████╗██║██║     ██║  ██║███████╗██║  ██║   ██║   ╚██████╔╝╚██████╔╝███████╗
 ╚═════╝╚═╝╚═╝     ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝   ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝
                  [ SAFE • SECURE • PROTECTED ]
       
            ");

            Console.ResetColor();
        }

        public static void TypingEffect(string message)
        {
            foreach (char c in message)
            {
                Console.Write(c);
                Thread.Sleep(20);
            }
            Console.WriteLine();
        }
    }
}